"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var app_employeeservices_1 = require("./app.employeeservices");
var AppComponent = (function () {
    function AppComponent(empservice) {
        this.empservice = empservice;
        this.data = {};
    }
    AppComponent.prototype.addAllEmployee = function () {
        this.data = { 'empId': this.empId, 'name': this.empName, 'salary': this.empSalary };
        this.myallData.push(this.data);
        this.empId = null;
        this.empName = "";
        this.empSalary = null;
    };
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.empservice.getAll().subscribe(function (data) { return _this.myallData = data; });
    };
    AppComponent.prototype.deleteEmployee = function (id) {
        var index = this.myallData.indexOf(id);
        if (index !== -1) {
            this.myallData.splice(index, 1);
        }
    };
    AppComponent.prototype.updateEmployee = function (temp) {
        var index = this.myallData.indexOf(temp);
        this.uempId = temp.empId;
        this.uempName = temp.name;
        this.uempSalary = temp.salary;
        this.vara = index;
    };
    AppComponent.prototype.update = function () {
        this.data = { 'empId': this.uempId, 'name': this.uempName, 'salary': this.uempSalary };
        this.myallData[this.vara] = this.data;
    };
    AppComponent.prototype.sorting = function (index) {
        if (index == 1)
            this.myallData.sort(this.sortById);
        else if (index == 2)
            this.myallData.sort(this.sortByName);
        else if (index == 3)
            this.myallData.sort(this.sortBySalary);
    };
    AppComponent.prototype.sortById = function (n1, n2) {
        if (n1.empId > n2.empId)
            return 1;
        else if (n1.empId == n2.empId)
            return 0;
        else
            return -1;
    };
    AppComponent.prototype.sortByName = function (n1, n2) {
        if (n1.name > n2.name)
            return 1;
        else if (n1.name == n2.name)
            return 0;
        else
            return -1;
    };
    AppComponent.prototype.sortBySalary = function (n1, n2) {
        if (n1.salary > n2.salary)
            return 1;
        else if (n1.salary == n2.salary)
            return 0;
        else
            return -1;
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        providers: [app_employeeservices_1.EmployeeService],
        templateUrl: './app.component.html'
    }),
    __metadata("design:paramtypes", [app_employeeservices_1.EmployeeService])
], AppComponent);
exports.AppComponent = AppComponent;
