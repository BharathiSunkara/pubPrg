
import {Component} from '@angular/core';

@Component({
    selector:'college-comp',
    templateUrl:'./app.college.html'
})
export class CollegeComponent{
    cname='Sree Dattha';
    cid='E4';
}