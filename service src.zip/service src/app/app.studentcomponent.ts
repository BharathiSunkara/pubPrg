
import {Component} from '@angular/core';

@Component({
    selector:'stu-comp',
    templateUrl:'./app.student.html',
   

})

export class StudentComponent{
    name='Harikrishna Kovuru';
    id='14E41A05D70';
}