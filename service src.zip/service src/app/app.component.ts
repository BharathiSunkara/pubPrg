import { Component, OnInit } from '@angular/core';
import {EmployeeService} from './app.employeeservices';
 
@Component({
  selector: 'my-app',

  providers:[EmployeeService],
  
  templateUrl:'./app.component.html'

})


export class AppComponent implements OnInit {
 
  empId:number;
  empName:String;
  empSalary:number;
  uempId:number;
  uempName:string;
  uempSalary:number;
  myallData:any;
  data:any={};

constructor(private empservice:EmployeeService){}
addAllEmployee(){
  this.data={'empId':this.empId,'name':this.empName,'salary':this.empSalary};
  this.myallData.push(this.data);
 
  this.empId=null;
  this.empName="";
  this.empSalary=null;
  
 }

ngOnInit(){
  this.empservice.getAll().subscribe((data:any)=>this.myallData=data);
}


deleteEmployee(id:any){
  const index:number= this.myallData.indexOf(id);
  if(index!==-1){
      this.myallData.splice(index,1);
      }
   
  }

  vara:any;
updateEmployee(temp:any):void{

      const index:number=this.myallData.indexOf(temp);
      this.uempId = temp.empId;
      this.uempName = temp.name;
      this.uempSalary= temp.salary;
      this.vara = index;

  }
  update():void{
    this.data={'empId':this.uempId,'name':this.uempName,'salary':this.uempSalary};

    this.myallData[this.vara]=this.data;

  }
  sorting(index:number):void {
    if(index==1)
    this.myallData.sort(this.sortById);
    else if(index==2)
    this.myallData.sort(this.sortByName);
    else if(index==3)
    this.myallData.sort(this.sortBySalary);
  }
     
    sortById(n1:any,n2:any){
    if(n1.empId > n2.empId) return 1;
    else if(n1.empId==n2.empId) return 0;
    else return -1;
    }
     
    sortByName(n1:any,n2:any){
    if(n1.name > n2.name) return 1;
    else if(n1.name==n2.name) return 0;
    else return -1;
    }
     
    sortBySalary(n1:any,n2:any){
    if(n1.salary> n2.salary) return 1;
    else if(n1.salary==n2.salary) return 0;
    else return -1;
    }
    

    

    // update():void{
    //   this.myallData={'empId':this.uempId,'name':this.uempName,'salary':this.uempSalary};

    

    // }




 
  }
